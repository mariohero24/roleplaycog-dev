# Roleplay Cog - version for py-cord-dev

Project is the same otherwise.